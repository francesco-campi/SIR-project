#ifndef INFECTION_STATUS_H
#define INFECTION_STATUS_H

enum InfectionStatus
{
    susceptible,
    infected,
    recovered
};

#endif